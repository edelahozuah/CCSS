Este directorio contiene certificados y claves públicas para los ejercicios del laboratorio.

Ejemplos de ficheros que puedes colocar aquí (según la guía):

- LabRootCA.crt
- LabSubCA.crt
- ca-weak.pem          (WeakRootCA.crt)
- tiny-root.pem        (Root de 256 bits para el reto de factorización)
- tiny-server.pem
- server-1.pem, server-2.pem, etc.

Estos ficheros se generan a partir de EJBCA y de openssl siguiendo los pasos de configuración inicial del laboratorio.
